class Product < ActiveRecord::Base
has_many :reviews
end
