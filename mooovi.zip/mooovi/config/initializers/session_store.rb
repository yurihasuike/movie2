# Be sure to restart your server when you modify this file.

TechReviewSite::Application.config.session_store :cookie_store, key: '_tech_review_site_session'
