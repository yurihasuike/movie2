require 'test_helper'

class TopHelperTest < ActionView::TestCase
end
